<?php
// เชื่อมต่อฐานข้อมูล
require 'conn.php';

// ตัวแปรสำหรับเก็บข้อความสถานะการเข้าสู่ระบบ
$statusMessage = '';
$statusType = '';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $username = $_POST['username'];
    $password = $_POST['password'];

    // ตรวจสอบ username และดึงข้อมูลผู้ใช้
    $sql = "SELECT * FROM users WHERE username='$username'";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        
        // ตรวจสอบรหัสผ่าน
        if (password_verify($password, $row['password'])) {
            // รหัสผ่านถูกต้อง
            $statusMessage = "Logged in successfully!";
            $statusType = "success";
            // ทำการตั้งค่าการเข้าสู่ระบบเช่น session ที่นี่
        } else {
            $statusMessage = "Invalid password.";
            $statusType = "error";
        }
    } else {
        $statusMessage = "No user found with that username.";
        $statusType = "error";
    }
}
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    <link rel="stylesheet" href="stylogin.css">
    <link rel="stylesheet" href="stymodal.css"> <!-- เชื่อมโยงไฟล์ modal.css -->
</head>
<body>
    <div class="login-container">
        <h1>Login</h1>
        <form method="POST" action="login.php">
            <div class="form-group">
                <label for="username">Username</label>
                <input type="text" id="username" name="username" required>
            </div>
            <div class="form-group">
                <label for="password">Password</label>
                <input type="password" id="password" name="password" required>
            </div>
            <button type="submit" class="login-btn">Login</button>
            
        </form>
       
        <a href='index.html'><button class="back-btn">Back</button></a>

    </div>

    <!-- Modal -->
    <div id="myModal" class="modal">
        <div class="modal-content">
            <span class="close">&times;</span>
            <p class="<?= $statusType; ?>"><?= $statusMessage; ?></p>
            <button onclick="closeModal()">OK</button>
        </div>
    </div>

    <script>
        // แสดง modal เมื่อมีข้อความสถานะ
        window.onload = function() {
            <?php if ($statusMessage): ?>
                document.getElementById('myModal').style.display = 'block';
            <?php endif; ?>
        }

        // ปิด modal
        function closeModal() {
            document.getElementById('myModal').style.display = 'none';
            <?php if ($statusType === 'success'): ?>
                window.location.href = 'mainmenu.html'; // เปลี่ยนเส้นทางหลังจากล็อกอินสำเร็จ
            <?php endif; ?>
        }

        // ปิด modal เมื่อคลิกที่ปุ่ม 'x'
        document.querySelector('.close').onclick = function() {
            closeModal();
        }
        
        // ปิด modal เมื่อคลิกนอก modal
        window.onclick = function(event) {
            if (event.target == document.getElementById('myModal')) {
                closeModal();
            }
        }
    </script>
</body>
</html>
