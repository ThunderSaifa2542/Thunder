<?php
    require 'conn.php';

    // ตรวจสอบว่ามีการส่งคำค้นหาหรือไม่
    $search = isset($_GET['search']) ? $_GET['search'] : '';

    // ใช้ JOIN เพื่อดึงข้อมูลจากทั้ง ordertb และ product โดยใช้ pdid เป็นคีย์เชื่อมโยง และกรองตามคำค้นหาถ้ามี
    // ป้องกัน SQL Injection โดยใช้ prepared statement
    $sql = "SELECT ordertb.oid, ordertb.pdid, ordertb.qnt, product.pname, product.price, product.details
            FROM ordertb
            JOIN product ON ordertb.pdid = product.pid
            WHERE ordertb.oid LIKE ? OR product.pname LIKE ?";
    $stmt = $conn->prepare($sql);
    $searchParam = "%$search%"; // เตรียมค่าค้นหา
    $stmt->bind_param("ss", $searchParam, $searchParam); // bind parameters
    $stmt->execute();
    $result = $stmt->get_result(); // ดึงข้อมูลจาก stmt

    if (!$result) {
        die("Error : " . $conn->error);
    }

    $totalPrice = 0; // ตัวแปรสำหรับเก็บราคาสุทธิรวม
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>This show Order</title>
    <link rel="stylesheet" href="styleorder.css"> 
    <script>
        function confirmDelete(pdid) {
            var result = confirm("คุณต้องการลบรายการนี้หรือไม่?");
            if(result) {
                window.location.href = "deleteorder.php?pdid=" + pdid;
            }
        }
    </script>
</head>
<body>

    <h1>Order</h1><br>  

    <!-- ฟอร์มสำหรับค้นหา -->
    <form method="GET" action="">
        <input type="text" name="search" placeholder="ค้นหาสินค้า หรือ Order ID" value="<?php echo htmlspecialchars($search); ?>">
        <button type="submit">ค้นหา</button>
    </form>

    <table> 
        <thead>
            <tr>
                <th>Order ID</th>
                <th>Product ID</th>
                <th>ชื่อรายการ</th>
                <th>ราคา</th>
                <th>รายละเอียด</th>
                <th>จำนวน</th>
                <th>ราคารวม</th> <!-- เพิ่มคอลัมน์สำหรับราคาสุทธิ -->
                <th>แก้ไข</th>
                <th>ลบ</th>
            </tr>
        </thead>
        <tbody>
            <?php 
                if ($result->num_rows > 0) {
                    while($row = $result->fetch_assoc()) {
                        $subtotal = $row["qnt"] * $row["price"]; // คำนวณราคาสุทธิสำหรับแต่ละรายการ
                        $totalPrice += $subtotal; // เพิ่มราคาสุทธิเข้ารวมทั้งหมด

                        echo "<tr>";
                        echo "<td>" . htmlspecialchars($row["oid"]) . "</td>";
                        echo "<td>" . htmlspecialchars($row["pdid"]) . "</td>";
                        echo "<td>" . htmlspecialchars($row["pname"]) . "</td>";
                        echo "<td>" . htmlspecialchars(number_format($row["price"], 2)) . "</td>"; // แสดงราคาในรูปแบบที่อ่านง่าย
                        echo "<td>" . htmlspecialchars($row["details"]) . "</td>";
                        echo "<td>" . htmlspecialchars($row["qnt"]) . "</td>";
                        echo "<td>" . htmlspecialchars(number_format($subtotal, 2)) . "</td>"; // แสดงราคารวมในรูปแบบที่อ่านง่าย
                        echo "<td><a href='editorder.php?pdid=" . htmlspecialchars($row["pdid"]) . "'><button>Edit</button></a></td>";
                        echo "<td><button class='delete' onclick='confirmDelete(\"" . htmlspecialchars($row["pdid"]) . "\")'>Delete</button></td>";
                        echo "</tr>";                        
                    }
                } else {
                    echo "<tr><td colspan='9'>ไม่พบข้อมูล</td></tr>"; // แสดงข้อความหากไม่มีข้อมูล
                }
                $stmt->close(); // ปิด statement
                $conn->close(); // ปิดการเชื่อมต่อฐานข้อมูล
            ?>
        </tbody>
    </table>  
    <br>
    <strong>ยอดขายรวม: <?php echo htmlspecialchars(number_format($totalPrice, 2)); ?></strong> <!-- แสดงราคารวม -->
    <br><br>
    <a href='insertorder.php'><button class="Insert">Insert Order</button></a>
    <a href='mainmenu.html'><button Class="Back">Back</button></a> 
</body>
</html>
