<?php
$search = isset($_GET['search']) ? $_GET['search'] : '';

// เชื่อมต่อฐานข้อมูล
require 'conn.php';

// SQL query สำหรับการค้นหาสินค้า
$sql = "SELECT * FROM product";
if (!empty($search)) {
    $sql .= " WHERE pid LIKE '%" . $conn->real_escape_string($search) . "%' OR pname LIKE '%" . $conn->real_escape_string($search) . "%'";
}

$result = $conn->query($sql);
if (!$result) {
    die("Error: " . $conn->error);
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>This show Product</title>
    <link rel="stylesheet" href="styleproduct.css"> 
    <script>
    function confirmDelete(pid) {
        // แสดงหน้าต่างยืนยันการลบ
        let confirmAction = confirm("คุณยืนยันที่จะลบรายการนี้หรือไม่?");
        if (confirmAction) {
            // ถ้าผู้ใช้กด "ตกลง" ให้ไปยัง deleteproduct.php พร้อมส่ง pid
            window.location.href = "deleteproduct.php?pid=" + pid;
        }
    }
    </script>
</head>
<body>
    <h1>Product</h1><br>  

    <!-- ฟอร์มสำหรับค้นหา -->
    <form method="GET" action="">
        <input type="text" name="search" placeholder="ค้นหาสินค้า หรือ Product ID" value="<?php echo htmlspecialchars($search); ?>">
        <button type="submit">ค้นหา</button>
    </form>

    <table> 
        <thead>
            <tr>
                <th>Product ID :</th>
                <th>ชื่อรายการ :</th>
                <th>ราคา :</th>
                <th>รายละเอียด :</th>
                <th>แก้ไข :</th>
                <th>ลบ :</th>
            </tr>
        </thead>
        <tbody>
            <?php 
            // แสดงข้อมูลจากฐานข้อมูล
            if ($result->num_rows > 0) {
                while ($row = $result->fetch_assoc()) {
                    echo "<tr>";
                    echo "<td>" . htmlspecialchars($row["pid"]) . "</td>";           // แสดง Product ID
                    echo "<td>" . htmlspecialchars($row["pname"]) . "</td>";          // แสดงชื่อเมนู
                    echo "<td>" . htmlspecialchars($row["price"]) . "</td>";          // แสดงราคา
                    echo "<td>" . htmlspecialchars($row["details"]) . "</td>";        // แสดงรายละเอียดของเมนู
                    echo "<td><a href='editproduct.php?pid=" . htmlspecialchars($row["pid"]) . "'><button>Edit</button></a></td>";  // ลิงก์สำหรับแก้ไข
                    echo "<td><button class='delete' onclick='confirmDelete(\"" . htmlspecialchars($row["pid"]) . "\")'>Delete</button></td>"; // ปุ่มลบที่มีฟังก์ชันยืนยัน
                    echo "</tr>";                        
                }
            } else {
                echo "<tr><td colspan='6'>ไม่มีผลลัพธ์</td></tr>";  // ถ้าไม่มีข้อมูลในฐานข้อมูล
            }
            $conn->close();
            ?>
        </tbody>
    </table>  
    <br>
    <a class="insert" href='insertproduct.php'><button class="Insert">Insert Order</button></a>
    <a href='mainmenu.html'><button class="Back">Back</button></a> 
    
</body>
</html>
