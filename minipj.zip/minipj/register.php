<?php
// เชื่อมต่อฐานข้อมูล
require 'conn.php';

// ตัวแปรสำหรับเก็บข้อความสถานะการลงทะเบียน
$statusMessage = '';
$statusType = '';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $username = $_POST['username'];
    $password = password_hash($_POST['password'], PASSWORD_BCRYPT); // เข้ารหัส password
    $birthday = $_POST['year'] . '-' . $_POST['month'] . '-' . $_POST['day'];
    $gender = $_POST['gender'];

    // ตรวจสอบว่า username ไม่ซ้ำ
    $checkUser = "SELECT * FROM users WHERE username='$username'";
    $result = $conn->query($checkUser);

    if ($result->num_rows > 0) {
        $statusMessage = "Register Successful.";
        $statusType = "success";
    } else {
        // บันทึกข้อมูลลงฐานข้อมูล
        $sql = "INSERT INTO users (username, password, birthday, gender) VALUES ('$username', '$password', '$birthday', '$gender')";

        if ($conn->query($sql) === TRUE) {
            $statusMessage = "Registration successful.<br> Please <a href='login.php'>login here</a>.";
            $statusType = "success";
        } else {
            $statusMessage = "Error: " . $sql . "<br>" . $conn->error;
            $statusType = "error";
        }
    }
}
$conn->close();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register Page</title>
    <link rel="stylesheet" href="styregis.css">
    <link rel="stylesheet" href="stymodal.css">

    <script>
        // แสดง modal เมื่อมีข้อความสถานะ
        window.onload = function() {
            <?php if ($statusMessage): ?>
                document.getElementById('myModal').style.display = 'block';
            <?php endif; ?>
        }

        // ปิด modal
        function closeModal() {
            document.getElementById('myModal').style.display = 'none';
            <?php if ($statusType === 'success'): ?>
                window.location.href = 'mainmenu.html'; // เปลี่ยนเส้นทางหลังจากล็อกอินสำเร็จ
            <?php endif; ?>
        }

        // ปิด modal เมื่อคลิกที่ปุ่ม 'x'
        document.querySelector('.close').onclick = function() {
            closeModal();
        }
        
        // ปิด modal เมื่อคลิกนอก modal
        window.onclick = function(event) {
            if (event.target == document.getElementById('myModal')) {
                closeModal();
            }
        }
    </script>      

    <script>
        function updateDays() {
            const monthSelect = document.getElementById('month');
            const daySelect = document.getElementById('day');
            const yearSelect = document.getElementById('year');
            
            const month = parseInt(monthSelect.value);
            const year = parseInt(yearSelect.value);

            // เก็บค่าที่เลือกไว้
            const selectedDay = parseInt(daySelect.value);

            // จำนวนวันในแต่ละเดือน (สำหรับเดือนกุมภาพันธ์ จะเช็ค leap year)
            const daysInMonth = [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
            
            // ตรวจสอบ leap year
            if (month === 2 && ((year % 4 === 0 && year % 100 !== 0) || year % 400 === 0)) {
                daysInMonth[1] = 29; // ปรับกุมภาพันธ์เป็น 29 วันถ้าเป็น leap year
            }
            
            // ลบรายการวันเก่าทั้งหมด
            daySelect.innerHTML = '<option value="">Day</option>';
            
            // สร้างรายการวันใหม่
            for (let i = 1; i <= daysInMonth[month - 1]; i++) {
                const option = document.createElement('option');
                option.value = i;
                option.textContent = i;
                daySelect.appendChild(option);
            }

            // ตั้งค่าคืนถ้ามีการเลือกวันแล้วและวันที่ยังอยู่ในขอบเขตของเดือนใหม่
            if (selectedDay && selectedDay <= daysInMonth[month - 1]) {
                daySelect.value = selectedDay;
            }
        }

        // เรียก updateDays เมื่อเลือกเดือนหรือปี
        window.onload = function() {
            document.getElementById('month').addEventListener('change', updateDays);
            document.getElementById('year').addEventListener('change', updateDays);
        };
    </script>

      

</head>
<body>
    
    <div class="background">
        <div class="register-container">
            <h1>Sign Up Your Account</h1>

            <?php if (!empty($statusMessage)): ?>
                <div class="<?php echo $statusType; ?>">
                    <?php echo $statusMessage; ?>
                </div>
            <?php endif; ?>

            <form method="POST" action="register.php">
                <!-- Birthday -->
                <div class="form-group">
                    <label for="birthday">Birthday</label>
                    <div class="birthday-select">
                        <select name="month" id="month" required>
                            <option value="">Month</option>
                            <option value="01">January</option>
                            <option value="02">February</option>
                            <option value="03">March</option>
                            <option value="04">April</option>
                            <option value="05">May</option>
                            <option value="06">June</option>
                            <option value="07">July</option>
                            <option value="08">August</option>
                            <option value="09">September</option>
                            <option value="10">October</option>
                            <option value="11">November</option>
                            <option value="12">December</option>
                        </select>

                        <select name="day" id="day" required>
                            <option value="">Day</option>
                        </select>

                        <select name="year" id="year" required>
                            <option value="">Year</option>
                            <?php for ($year = 1980; $year <= 2024; $year++): ?>
                                <option value="<?php echo $year; ?>"><?php echo $year; ?></option>
                            <?php endfor; ?>
                        </select>
                    </div>
                </div>

                <!-- Username -->
                <div class="form-group">
                    <label for="username">Username</label>
                    <input type="text" id="username" name="username" placeholder="Enter your username" required>
                </div>

                <!-- Password -->
                <div class="form-group">
                    <label for="password">Password</label>
                    <input type="password" id="password" name="password" placeholder="At least 8 characters" required>
                </div>

                <!-- Gender (optional) -->
                <div class="form-group">
                    <label for="gender">Gender (optional)</label>
                    <select name="gender" id="gender">
                        <option value="male">Male</option>
                        <option value="female">Female</option>
                        <option value="other">Other</option>
                    </select>
                </div>

                <button type="submit" class="signup-btn">Sign Up</button>
            </form>
            <a href='index.html'><button class="back-btn">Back</button></a>
        </div>
    </div>

    <!-- Modal -->
    <div id="myModal" class="modal">
        <div class="modal-content">
            <span class="close">&times;</span>
            <p class="<?= $statusType; ?>"><?= $statusMessage; ?></p>
            <button onclick="closeModal()">OK</button>
        </div>
    </div>

                     

</body>
</html>
