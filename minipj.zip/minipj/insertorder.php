<?php
    require 'conn.php';

    // ตรวจสอบว่าเมื่อฟอร์มถูกส่งแล้ว
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        $oid = $_POST['oid']; // Order ID
        $pdid = $_POST['pdid'];
        $qnt = $_POST['qnt'];

        // ตรวจสอบว่ามีข้อมูลที่จำเป็นหรือไม่
        if (!empty($oid) && !empty($pdid) && !empty($qnt)) {
            // ตรวจสอบว่า Order ID ซ้ำกับที่มีอยู่หรือไม่
            $check_sql = "SELECT * FROM ordertb WHERE oid = ?";
            $check_stmt = $conn->prepare($check_sql);
            $check_stmt->bind_param("s", $oid); // ใช้ "s" สำหรับ VARCHAR
            $check_stmt->execute();
            $check_result = $check_stmt->get_result();

            if ($check_result->num_rows > 0) {
                echo "<script>alert('Order ID นี้มีอยู่แล้ว');</script>";
            } else {
                // เพิ่มข้อมูลลงใน ordertb
                $sql = "INSERT INTO ordertb (oid, pdid, qnt) VALUES (?, ?, ?)";
                $stmt = $conn->prepare($sql);
                $stmt->bind_param("ssi", $oid, $pdid, $qnt); // ใช้ "ssi" สำหรับ VARCHAR และ INT
                if ($stmt->execute()) {
                    echo "<script>alert('เพิ่มรายการสำเร็จ');</script>";
                    header("Location: mainorder.php"); // เปลี่ยนเส้นทางไปยังหน้าแสดง Order
                    exit();
                } else {
                    echo "Error: " . $conn->error;
                }
            }
        } else {
            echo "<script>alert('กรุณากรอกข้อมูลให้ครบถ้วน');</script>";
        }
    }

    // ดึงข้อมูลสินค้าจากตาราง product เพื่อแสดงในตัวเลือก
    $product_sql = "SELECT pid, pname FROM product";
    $product_result = $conn->query($product_sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Insert Order</title>
    <link rel="stylesheet" href="styleinsert.css"> <!-- สไตล์ CSS -->
</head>
<body>
    <h1>Insert Order</h1>
    <form method="POST" action="">

        <label for="oid">Order ID:</label>
        <input type="text" id="oid" name="oid" required><br><br> <!-- เปลี่ยนเป็น type="text" -->

        <label for="pdid">เลือกสินค้า:</label>
        <select name="pdid" id="pdid" required>
            <option value="">-- กรุณาเลือกสินค้า --</option>
            <?php
                if ($product_result->num_rows > 0) {
                    while($product_row = $product_result->fetch_assoc()) {
                        echo "<option value='".$product_row['pid']."'>".$product_row['pname']."</option>";
                    }
                }
            ?>
        </select><br><br>

        <label for="qnt">จำนวน:</label>
        <input type="number" id="qnt" name="qnt" required><br><br>

        <button type="submit">บันทึกข้อมูล</button>
        <a href="mainorder.php"><button type="button">ยกเลิก</button></a> <!-- ปุ่มยกเลิก -->
    </form>

    <?php $conn->close(); ?>
</body>
</html>
