<?php
    require 'conn.php'; // เชื่อมต่อฐานข้อมูล

    // ตรวจสอบว่ามีการส่ง pid มาหรือไม่
    if (isset($_GET['pid'])) {
        $pid = $_GET['pid'];

        // SQL query สำหรับลบข้อมูลจาก product โดยใช้ pid
        $sql = "DELETE FROM product WHERE pid = ?";
        
        // เตรียม statement และ bind พารามิเตอร์
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("s", $pid);
        
        // ดำเนินการลบ
        if ($stmt->execute()) {
            // ถ้าสำเร็จ แสดงข้อความ success และเปลี่ยนเส้นทางกลับไปยังหน้าหลัก
            echo "<script>
                    alert('Delete Success');
                    window.location.href = 'mainproduct.php';  // เปลี่ยนเป็นชื่อไฟล์ของคุณ
                  </script>";
        } else {
            // ถ้าลบไม่สำเร็จ แสดง error
            echo "<script>
                    alert('Delete Failed: " . $conn->error . "');
                    window.location.href = 'mainproduct.php';
                  </script>";
        }
        $stmt->close(); // ปิด statement
    } else {
        // ถ้าไม่มี pid ให้กลับไปหน้าหลัก
        echo "<script>
                alert('No Product ID provided');
                window.location.href = 'mainproduct.php';
              </script>";
    }

    $conn->close(); // ปิดการเชื่อมต่อฐานข้อมูล
?>
