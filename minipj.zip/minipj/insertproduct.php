<?php
    require 'conn.php';

    // ตรวจสอบว่าเมื่อฟอร์มถูกส่งแล้ว
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        $pid = $_POST['pid']; // Product ID
        $pname = $_POST['pname']; // ชื่อรายการ (ชื่อสินค้า)
        $price = $_POST['price']; // ราคา
        $details = $_POST['details']; // รายละเอียด

        // ตรวจสอบว่ามีข้อมูลที่จำเป็นหรือไม่
        if (!empty($pid) && !empty($pname) && !empty($price) && !empty($details)) {
            // ตรวจสอบว่า Product ID ซ้ำกับที่มีอยู่หรือไม่
            $check_sql = "SELECT * FROM product WHERE pid = ?";
            $check_stmt = $conn->prepare($check_sql);
            $check_stmt->bind_param("s", $pid); // ใช้ "s" สำหรับ VARCHAR
            $check_stmt->execute();
            $check_result = $check_stmt->get_result();

            if ($check_result->num_rows > 0) {
                echo "<script>alert('Product ID นี้มีอยู่แล้ว');</script>";
            } else {
                // เพิ่มข้อมูลลงใน product
                $sql = "INSERT INTO product (pid, pname, price, details) VALUES (?, ?, ?, ?)";
                $stmt = $conn->prepare($sql);
                $stmt->bind_param("ssis", $pid, $pname, $price, $details); // ใช้ "ssis" สำหรับ VARCHAR และ INT
                if ($stmt->execute()) {
                    echo "<script>alert('เพิ่มสินค้าสำเร็จ');</script>";
                    header("Location: mainproduct.php"); // เปลี่ยนเส้นทางไปยังหน้าแสดง Product
                    exit();
                } else {
                    echo "Error: " . $conn->error;
                }
            }
        } else {
            echo "<script>alert('กรุณากรอกข้อมูลให้ครบถ้วน');</script>";
        }
    }
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Insert Product</title>
    <link rel="stylesheet" href="styleinsert.css"> <!-- สไตล์ CSS -->
</head>
<body>
    <h1>Insert Product</h1>
    <form method="POST" action="">

        <label for="pid">Product ID:</label>
        <input type="text" id="pid" name="pid" required><br><br> <!-- ฟิลด์ Product ID -->

        <label for="pname">ชื่อรายการ (สินค้า):</label>
        <input type="text" id="pname" name="pname" required><br><br> <!-- ฟิลด์ ชื่อรายการ (สินค้า) -->

        <label for="price">ราคา:</label>
        <input type="number" id="price" name="price" required><br><br> <!-- ฟิลด์ ราคา -->

        <label for="details">รายละเอียด:</label>
        <textarea id="details" name="details" rows="4" cols="50" required></textarea><br><br> <!-- ฟิลด์ รายละเอียด -->

        <button type="submit">บันทึกข้อมูล</button>
        <a href="mainproduct.php"><button type="button">ยกเลิก</button></a> <!-- ปุ่มยกเลิก -->
    </form>

    <?php $conn->close(); ?>
</body>
</html>
