-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Oct 05, 2024 at 10:05 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `kfbstore`
--

-- --------------------------------------------------------

--
-- Table structure for table `ordertb`
--
-- สร้างตาราง ordertb ใหม่ โดยไม่ต้องมี pname, price, details และเพิ่ม foreign key
CREATE TABLE `ordertb` (
  `oid` varchar(3) NOT NULL,
  `pid` varchar(3) NOT NULL,
  `quantity` int(11) NOT NULL,
  PRIMARY KEY (`oid`),
  FOREIGN KEY (`pid`) REFERENCES `product`(`pid`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- เพิ่มข้อมูลเข้าไปใน ordertb เฉพาะ oid, pid, quantity
INSERT INTO `ordertb` (`oid`, `pid`, `quantity`) VALUES
('001', '001', 2),
('002', '002', 3),
('003', '003', 1),
('004', '004', 4),
('005', '005', 1),
('006', '006', 5),
('007', '007', 2),
('008', '008', 3),
('009', '009', 1),
('010', '010', 2),
('011', '011', 3),
('012', '012', 1),
('013', '013', 2),
('014', '014', 3),
('015', '015', 1);

-- ดึงข้อมูลจาก ordertb และ product โดยใช้ JOIN
SELECT o.oid, o.quantity, p.pname, p.price, p.details
FROM `ordertb` o
JOIN `product` p ON o.pid = p.pid;

-- --------------------------------------------------------

--
-- Table structure for table `product`
--

CREATE TABLE `product` (
  `pid` varchar(3) NOT NULL,
  `pname` varchar(80) NOT NULL,
  `price` int(4) NOT NULL,
  `details` varchar(120) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `product`
--

INSERT INTO `product` (`pid`, `pname`, `price`, `details`) VALUES
('001', 'น่องไก่', 20, 'น่องไก่ 1 ชิ้น'),
('002', 'สะโพกไก่', 20, 'สะโพกไก่ 1 ชิ้น'),
('003', 'ปีกไก่', 20, 'ปีกไก่ 1 ชิ้น'),
('004', 'ไก่วิงค์แซ่บ', 25, 'ไก่วิงค์แซ่บ 1 ชิ้น'),
('005', 'ทาร์ตไข่', 25, 'ทาร์ตไข่ 1 ชิ้น'),
('006', 'นักเก็ตไก่', 30, 'นักเก็ตไก่ 5 ชิ้น'),
('007', 'เฟรนฟราย', 30, 'เฟรนฟราย 1 กล่อง'),
('008', 'มันบด', 25, 'มันบด 1 ถ้วย'),
('009', 'ออลอินวันบักเก็ต', 159, 'น่องไก่ 2, สะโพกไก่ 2, ไก่วิงค์แซ่บ 4,  เฟรนฟราย 1, มันบด 1 ถ้วย'),
('010', 'แป็บซี่', 20, 'แป็บซี่ 1 แก้ว (รีฟิล)'),
('011', 'ชุดไก่จุใจ', 159, 'น่องไก่ 2 ชิ้น, สะโพกไก่ 2 ชิ้น, เฟรนฟราย 1 กล่อง, นักเก็ตไก่ 1 ชุด, แป๊บซี่ 2 แก้ว'),
('012', 'เดอะบอกซ์ ซิกเนเจอร์ เลเยอร์คัสตอม', 129, 'น่องไก่ 1 ชิ้น, สะโพกไก่ 1 ชิ้น, ทาร์ตไข่ 1 ชิ้น, ไก่วิงค์แซ่บ 2 ชิ้น, เฟรนฟราย 1 ชิ้น, แป๊บซี่ 1 แก้ว'),
('013', 'เดอะบอกซ์ ไก่เทนเดอร์ สูตรเชฟเอียน', 99, 'น่องไก่ 2 ชิ้น, ไก่วิงค์แซ่บ 2 ชิ้น, เฟรนฟราย 1 กล่อง, แป๊บซี่ 1 แก้ว'),
('014', 'ไก่โดนใจ 1', 59, 'น่องไก่ 1 ชิ้น, สะโพกไก่ 1 ชิ้น, เฟรนฟราย 1 กล่อง, แป๊บซี่ 1 แก้ว'),
('015', 'ฟอร์วันมิล', 79, 'น่องไก่ 1 ชิ้น, สะโพกไก่ 1 ชิ้น, เฟรนฟราย 1 ชิ้น, นักเก็ตไก่ 1 ชิ้น ,แป๊บซี่ 1แก้ว');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `ordertb`
--
ALTER TABLE `ordertb`
  ADD PRIMARY KEY (`oid`),
  ADD KEY `pid` (`pid`),
  ADD KEY `pname` (`pname`),
  ADD KEY `price` (`price`),
  ADD KEY `details` (`details`);

--
-- Indexes for table `product`
--
ALTER TABLE `product`
  ADD PRIMARY KEY (`pid`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
