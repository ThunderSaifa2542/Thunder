<?php
    require 'conn.php';

    // ตรวจสอบว่ามีการส่งค่า pdid หรือไม่
    if (isset($_GET['pdid'])) {
        $pdid = $_GET['pdid'];

        // ดึงข้อมูลจากฐานข้อมูลเพื่อแสดงในฟอร์มแก้ไข
        $sql = "SELECT ordertb.oid, ordertb.pdid, ordertb.qnt, product.pname, product.price, product.details
                FROM ordertb
                JOIN product ON ordertb.pdid = product.pid
                WHERE ordertb.pdid = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("i", $pdid);
        $stmt->execute();
        $result = $stmt->get_result();
        
        if ($result->num_rows == 1) {
            $row = $result->fetch_assoc();
        } else {
            die("ไม่พบข้อมูลคำสั่งซื้อที่คุณต้องการแก้ไข");
        }

        // เมื่อผู้ใช้ส่งฟอร์มแก้ไข
        if ($_SERVER["REQUEST_METHOD"] == "POST") {
            $new_qnt = $_POST['qnt'];
            $new_price = $_POST['price'];
            $new_details = $_POST['details'];  // รับข้อมูลรายละเอียดจากฟอร์ม

            // อัปเดตข้อมูลลงฐานข้อมูล
            $update_sql = "UPDATE ordertb 
                           JOIN product ON ordertb.pdid = product.pid 
                           SET ordertb.qnt = ?, product.price = ?, product.details = ?
                           WHERE ordertb.pdid = ?";
            $update_stmt = $conn->prepare($update_sql);
            $update_stmt->bind_param("iiss", $new_qnt, $new_price, $new_details, $pdid);  // ใช้ "iiss" สำหรับข้อมูลที่เป็น string ในฟิลด์ details
            if ($update_stmt->execute()) {
                // ถ้าอัปเดตสำเร็จให้เปลี่ยนเส้นทางไปที่หน้าหลัก
                header("Location: mainorder.php");
                exit();
            } else {
                echo "Error: " . $conn->error;
            }
        }
    } else {
        die("ไม่มีข้อมูลเพื่อแก้ไข");
    }

    $conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Order</title>
    <link rel="stylesheet" href="styleeditorder.css"> <!-- ลิงก์ CSS -->
</head>
<body>
    <h1>Edit Order</h1>

    <form method="POST" action="">
        <label for="pname">ชื่อสินค้า:</label>
        <input type="text" id="pname" name="pname" value="<?php echo $row['pname']; ?>" readonly><br><br>

        <label for="qnt">จำนวน:</label>
        <input type="number" id="qnt" name="qnt" value="<?php echo $row['qnt']; ?>"><br><br>

        <label for="price">ราคา:</label>
        <input type="number" step="1" id="price" name="price" value="<?php echo $row['price']; ?>"><br><br>

        <label for="details">รายละเอียด:</label>
        <textarea id="details" name="details" readonly><?php echo $row['details']; ?></textarea><br><br>


        <button type="submit">บันทึกการแก้ไข</button>
        <a href="mainorder.php"><button type="button">ยกเลิก</button></a> <!-- ปุ่มยกเลิกกลับไปหน้าหลัก -->
    </form>
</body>
</html>
