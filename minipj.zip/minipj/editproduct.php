<?php
    require 'conn.php';

    // ตรวจสอบว่ามีการส่งค่า pid หรือไม่
    if (isset($_GET['pid'])) {
        $pid = $_GET['pid'];

        // ดึงข้อมูลสินค้าจากฐานข้อมูลเพื่อแสดงในฟอร์มแก้ไข
        $sql = "SELECT pid, pname, price, details FROM product WHERE pid = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("s", $pid); // ใช้ "s" สำหรับ VARCHAR
        $stmt->execute();
        $result = $stmt->get_result();
        
        if ($result->num_rows == 1) {
            $row = $result->fetch_assoc();
        } else {
            die("ไม่พบข้อมูลสินค้าที่คุณต้องการแก้ไข");
        }

        // เมื่อผู้ใช้ส่งฟอร์มแก้ไข
        if ($_SERVER["REQUEST_METHOD"] == "POST") {
            $new_pid = $_POST['pid'];
            $new_pname = $_POST['pname'];
            $new_price = $_POST['price'];
            $new_details = $_POST['details'];

            // อัปเดตข้อมูลลงฐานข้อมูล
            $update_sql = "UPDATE product SET pid = ?, pname = ?, price = ?, details = ? WHERE pid = ?";
            $update_stmt = $conn->prepare($update_sql);
            $update_stmt->bind_param("ssiss", $new_pid, $new_pname, $new_price, $new_details, $pid); // ใช้ "ssiss" สำหรับ string และ int
            if ($update_stmt->execute()) {
                // ถ้าอัปเดตสำเร็จให้เปลี่ยนเส้นทางไปที่หน้าหลัก
                header("Location: mainproduct.php");
                exit();
            } else {
                echo "Error: " . $conn->error;
            }
        }
    } else {
        die("ไม่มีข้อมูลเพื่อแก้ไข");
    }

    $conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Product</title>
    <link rel="stylesheet" href="styleeditproduct.css"> <!-- ลิงก์ CSS -->
</head>
<body>
    <h1>Edit Product</h1>

    <form method="POST" action="">
        <label for="pid">Product ID:</label>
        <input type="text" id="pid" name="pid" value="<?php echo $row['pid']; ?>" required><br><br> <!-- ฟิลด์ Product ID -->

        <label for="pname">ชื่อรายการ (สินค้า):</label>
        <input type="text" id="pname" name="pname" value="<?php echo $row['pname']; ?>" required><br><br> <!-- ฟิลด์ ชื่อสินค้า -->

        <label for="price">ราคา:</label>
        <input type="number" id="price" name="price" value="<?php echo $row['price']; ?>" required><br><br> <!-- ฟิลด์ ราคา -->

        <label for="details">รายละเอียด:</label>
        <textarea id="details" name="details" rows="4" cols="50" required><?php echo $row['details']; ?></textarea><br><br> <!-- ฟิลด์ รายละเอียด -->

        <button type="submit">บันทึกการแก้ไข</button>
        <a href="mainproduct.php"><button type="button">ยกเลิก</button></a> <!-- ปุ่มยกเลิกกลับไปหน้าหลัก -->
    </form>
</body>
</html>
