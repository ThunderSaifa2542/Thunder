<?php
    require 'conn.php';  // เชื่อมต่อฐานข้อมูล

    // ตรวจสอบว่ามีการส่ง pdid มาหรือไม่
    if (isset($_GET['pdid'])) {
        $pdid = $_GET['pdid'];

        // SQL query สำหรับลบข้อมูลจาก ordertb
        $sql = "DELETE FROM ordertb WHERE pdid = ?";
        
        // เตรียม statement และ bind พารามิเตอร์
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("s", $pdid);
        
        // ดำเนินการลบ
        if ($stmt->execute()) {
            // ถ้าสำเร็จ ให้แสดงข้อความ success และเปลี่ยนเส้นทางกลับไปยังหน้าหลักพร้อมกับแจ้งเตือน
            echo "<script>
                    alert('Delete Success');
                    window.location.href = 'mainorder.php'; // เปลี่ยนเส้นทางไปหน้าหลักของ order
                  </script>";
        } else {
            // ถ้าลบไม่สำเร็จ ให้แสดง error
            echo "<script>
                    alert('Delete Failed: " . $conn->error . "');
                    window.location.href = 'mainorder.php'; 
                  </script>";
        }
        $stmt->close();  // ปิด statement
    } else {
        // ถ้าไม่มี pdid ให้กลับไปหน้าหลัก
        echo "<script>
                alert('No Product ID provided');
                window.location.href = 'mainorder.php'; 
              </script>";
    }

    $conn->close();  // ปิดการเชื่อมต่อฐานข้อมูล
?>
